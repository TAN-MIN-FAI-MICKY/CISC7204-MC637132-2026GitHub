# Module 05 Wildfire Practice Project

This folder contains the completed Part 1 analysis notebook (R-01 to R-10) and the Part 2 Dash application (R-11 to R-16). The course wildfire CSV is bundled under `attachments/`, so the notebook and dashboard can run without downloading it again.

## Run the notebook

Open `CISC7204 Assgn02 Module 05 Practice Lab01 Analyzing wildfire activities in Australia.ipynb` in Jupyter and run all cells from top to bottom.

## Run the dashboard

From this folder, install the listed packages and start the app:

```powershell
python -m pip install -r requirements.txt
python Dash_wildfire.py
```

The terminal prints a local URL (normally `http://127.0.0.1:8050/`). The dashboard lets you choose a region and year, then updates the monthly mean fire-area pie chart and mean presumed-vegetation-fire pixel-count bar chart.
