"""Australia wildfire dashboard for Module 05 Practice Project, Part 2.
Requirement coverage: R-11 to R-16 (Moodle 1241906).
"""
from pathlib import Path
import calendar

import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, html

DATA_URL = "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/Historical_Wildfires.csv"
DATA_PATH = Path(__file__).resolve().parent / "attachments" / "Historical_Wildfires.csv"
MONTH_ORDER = list(calendar.month_name[1:])
REGION_OPTIONS = [
    {"label": "New South Wales", "value": "NSW"},
    {"label": "Northern Territory", "value": "NT"},
    {"label": "Queensland", "value": "QL"},
    {"label": "South Australia", "value": "SA"},
    {"label": "Tasmania", "value": "TA"},
    {"label": "Victoria", "value": "VI"},
    {"label": "Western Australia", "value": "WA"},
]

# Prefer the bundled CSV so the dashboard also runs offline; use the course URL as a fallback.
df = pd.read_csv(DATA_PATH if DATA_PATH.is_file() else DATA_URL)
df["Date"] = pd.to_datetime(df["Date"])
df["Year"] = df["Date"].dt.year
df["Month"] = df["Date"].dt.month_name()
df["MonthNumber"] = df["Date"].dt.month
AVAILABLE_YEARS = sorted(df["Year"].unique().tolist())

app = Dash(__name__)
app.title = "Australia Wildfire Dashboard"
app.config.suppress_callback_exceptions = True

app.layout = html.Div(
    children=[
        html.H1(
            "Australia Wildfire Dashboard",
            style={"textAlign": "center", "color": "#503D36", "fontSize": 26},
        ),
        html.Div(
            children=[
                html.Div(
                    children=[
                        html.H2("Select Region:", style={"marginRight": "1em"}),
                        dcc.RadioItems(
                            options=REGION_OPTIONS,
                            value="NSW",
                            id="region",
                            inline=True,
                            labelStyle={"display": "inline-block", "marginRight": "0.75rem", "marginBottom": "0.35rem"},
                        ),
                        html.H2("Select Year:", style={"marginTop": "1.5rem"}),
                        dcc.Dropdown(
                            options=[{"label": str(year), "value": year} for year in AVAILABLE_YEARS],
                            value=AVAILABLE_YEARS[0],
                            id="year",
                            clearable=False,
                        ),
                    ],
                    style={"flex": "0 0 240px", "padding": "1rem"},
                ),
                html.Div(
                    children=[
                        html.Div([], id="plot1"),
                        html.Div([], id="plot2"),
                    ],
                    style={
                        "flex": "1",
                        "display": "grid",
                        "gridTemplateColumns": "repeat(auto-fit, minmax(360px, 1fr))",
                        "gap": "1rem",
                    },
                ),
            ],
            style={"display": "flex", "alignItems": "flex-start", "gap": "1rem"},
        ),
    ],
    style={"fontFamily": "Arial, sans-serif", "maxWidth": "1500px", "margin": "auto"},
)


@app.callback(
    [Output(component_id="plot1", component_property="children"),
     Output(component_id="plot2", component_property="children")],
    [Input(component_id="region", component_property="value"),
     Input(component_id="year", component_property="value")],
)
def reg_year_display(input_region, input_year):
    """Return monthly mean fire-area and pixel-count charts for a selection."""
    selected = df[(df["Region"] == input_region) & (df["Year"] == int(input_year))]

    est_data = (
        selected.groupby("Month", as_index=False)["Estimated_fire_area"]
        .mean()
        .assign(Month=lambda data: pd.Categorical(data["Month"], MONTH_ORDER, ordered=True))
        .sort_values("Month")
    )
    veg_data = (
        selected.groupby("Month", as_index=False)["Count"]
        .mean()
        .assign(Month=lambda data: pd.Categorical(data["Month"], MONTH_ORDER, ordered=True))
        .sort_values("Month")
    )

    fig1 = px.pie(
        est_data,
        values="Estimated_fire_area",
        names="Month",
        title=f"{input_region}: Monthly Average Estimated Fire Area in {input_year}",
        category_orders={"Month": MONTH_ORDER},
    )
    fig2 = px.bar(
        veg_data,
        x="Month",
        y="Count",
        title=f"{input_region}: Monthly Average Count of Vegetation-Fire Pixels in {input_year}",
        category_orders={"Month": MONTH_ORDER},
        labels={"Month": "Month", "Count": "Average pixel count"},
    )
    fig2.update_layout(xaxis={"categoryorder": "array", "categoryarray": MONTH_ORDER})

    return [dcc.Graph(figure=fig1), dcc.Graph(figure=fig2)]


if __name__ == "__main__":
    app.run(debug=False)
