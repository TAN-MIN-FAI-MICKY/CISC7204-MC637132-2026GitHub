# R-12, R-13, R-14, R-15, R-16, R-17, R-19
"""Interactive automobile sales dashboard for the Module 05 final lab."""

from pathlib import Path

import dash
import pandas as pd
import plotly.express as px
from dash import dcc, html
from dash.dependencies import Input, Output


DATA_URL = (
    "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/"
    "d51iMGfp_t0QpO30Lym-dw/automobile-sales.csv"
)
REPORT_YEARLY = "Yearly Statistics"
REPORT_RECESSION = "Recession Period Statistics"
MONTH_ORDER = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
VEHICLE_ORDER = ["SuperMiniCar", "SmallFamilyCar", "MediumFamilyCar", "ExecutiveCar", "Sports"]


def load_data() -> pd.DataFrame:
    """Load the bundled course data, falling back to its public course URL."""
    app_dir = Path(__file__).resolve().parent
    candidates = [
        app_dir / "automobile-sales.csv",
        app_dir.parent / "attachments" / "automobile-sales.csv",
        app_dir.parent.parent / "module05_final_work" / "attachments" / "automobile-sales.csv",
    ]
    data_path = next((path for path in candidates if path.exists()), None)
    if data_path is None:
        frame = pd.read_csv(DATA_URL)
    else:
        frame = pd.read_csv(data_path)
    frame["Date"] = pd.to_datetime(frame["Date"])
    frame["Month"] = pd.Categorical(frame["Month"].str[:3], categories=MONTH_ORDER, ordered=True)
    return frame


data = load_data()
year_list = sorted(data["Year"].dropna().astype(int).unique().tolist())

app = dash.Dash(__name__)
app.title = "Automobile Sales Statistics Dashboard"

REPORT_OPTIONS = [
    {"label": "Select Statistics", "value": "Select Statistics", "disabled": True},
    {"label": REPORT_YEARLY, "value": REPORT_YEARLY},
    {"label": REPORT_RECESSION, "value": REPORT_RECESSION},
]
YEAR_OPTIONS = [
    {"label": "Select-year", "value": "Select-year", "disabled": True},
    *[{"label": year, "value": year} for year in year_list],
]

app.layout = html.Div(
    [
        html.H1(
            "Automobile Sales Statistics Dashboard",
            style={"textAlign": "center", "color": "#503D36", "fontSize": 24},
        ),
        html.Div(
            [
                html.Label("Select Statistics:", htmlFor="dropdown-statistics"),
                dcc.Dropdown(
                    id="dropdown-statistics",
                    options=REPORT_OPTIONS,
                    value="Select Statistics",
                    placeholder="Select a report type",
                    clearable=False,
                    style={
                        "width": "80%",
                        "padding": "3px",
                        "fontSize": "20px",
                        "textAlignLast": "center",
                    },
                ),
            ],
            style={"margin": "12px 0"},
        ),
        html.Div(
            [
                html.Label("Select Year:", htmlFor="select-year"),
                dcc.Dropdown(
                    id="select-year",
                    options=YEAR_OPTIONS,
                    value="Select-year",
                    placeholder="Select-year",
                    disabled=True,
                    clearable=False,
                    style={
                        "width": "80%",
                        "padding": "3px",
                        "fontSize": "20px",
                        "textAlignLast": "center",
                    },
                ),
            ],
            style={"margin": "12px 0"},
        ),
        html.Div(
            "Choose a report type to display its four charts.",
            id="output-container",
            className="chart-grid",
            style={"display": "flex", "flexDirection": "column", "gap": "12px"},
        ),
    ],
    style={"fontFamily": "Arial, sans-serif", "margin": "20px auto", "maxWidth": "1500px"},
)


def update_input_container(selected_statistics):
    """Enable year selection only for the yearly report."""
    return selected_statistics != REPORT_YEARLY


def make_recession_figures() -> list:
    """Build the four plots required for the recession report."""
    recession_data = data.loc[data["Recession"] == 1]

    yearly_rec = recession_data.groupby("Year", as_index=False)["Automobile_Sales"].mean()
    chart1 = px.line(
        yearly_rec,
        x="Year",
        y="Automobile_Sales",
        markers=True,
        title="Average Automobile Sales Fluctuation over Recession Period",
        labels={"Automobile_Sales": "Average automobile sales", "Year": "Year"},
    )

    average_sales = recession_data.groupby("Vehicle_Type", as_index=False)["Automobile_Sales"].mean()
    average_sales["Vehicle_Type"] = pd.Categorical(average_sales["Vehicle_Type"], VEHICLE_ORDER, ordered=True)
    average_sales = average_sales.sort_values("Vehicle_Type")
    chart2 = px.bar(
        average_sales,
        x="Vehicle_Type",
        y="Automobile_Sales",
        title="Average Vehicles Sold by Vehicle Type during Recessions",
        labels={"Automobile_Sales": "Average automobile sales", "Vehicle_Type": "Vehicle type"},
    )

    exp_rec = recession_data.groupby("Vehicle_Type", as_index=False)["Advertising_Expenditure"].sum()
    exp_rec["Vehicle_Type"] = pd.Categorical(exp_rec["Vehicle_Type"], VEHICLE_ORDER, ordered=True)
    exp_rec = exp_rec.sort_values("Vehicle_Type")
    chart3 = px.pie(
        exp_rec,
        values="Advertising_Expenditure",
        names="Vehicle_Type",
        title="Advertising Expenditure Share by Vehicle Type during Recessions",
    )

    unemp_data = (
        recession_data.groupby(["unemployment_rate", "Vehicle_Type"], as_index=False)["Automobile_Sales"]
        .mean()
    )
    chart4 = px.bar(
        unemp_data,
        x="unemployment_rate",
        y="Automobile_Sales",
        color="Vehicle_Type",
        barmode="group",
        labels={
            "unemployment_rate": "Unemployment rate (%)",
            "Automobile_Sales": "Average automobile sales",
            "Vehicle_Type": "Vehicle type",
        },
        title="Effect of Unemployment Rate on Vehicle Type and Sales",
    )
    return [chart1, chart2, chart3, chart4]


def make_yearly_figures(input_year: int) -> list:
    """Build the four plots required for the selected-year report."""
    yearly_data = data.loc[data["Year"] == int(input_year)]
    if yearly_data.empty:
        return []

    yearly_sales = data.groupby("Year", as_index=False)["Automobile_Sales"].mean()
    chart1 = px.line(
        yearly_sales,
        x="Year",
        y="Automobile_Sales",
        markers=True,
        title="Average Automobile Sales by Year (1980–2023)",
        labels={"Automobile_Sales": "Average automobile sales", "Year": "Year"},
    )

    monthly_sales = yearly_data.groupby("Month", observed=False, as_index=False)["Automobile_Sales"].sum()
    monthly_sales = monthly_sales.dropna(subset=["Automobile_Sales"]).sort_values("Month")
    chart2 = px.line(
        monthly_sales,
        x="Month",
        y="Automobile_Sales",
        markers=True,
        title=f"Total Monthly Automobile Sales in {input_year}",
        labels={"Automobile_Sales": "Total automobile sales", "Month": "Month"},
    )

    average_vehicle_sales = yearly_data.groupby("Vehicle_Type", as_index=False)["Automobile_Sales"].mean()
    average_vehicle_sales["Vehicle_Type"] = pd.Categorical(
        average_vehicle_sales["Vehicle_Type"], VEHICLE_ORDER, ordered=True
    )
    average_vehicle_sales = average_vehicle_sales.sort_values("Vehicle_Type")
    chart3 = px.bar(
        average_vehicle_sales,
        x="Vehicle_Type",
        y="Automobile_Sales",
        title=f"Average Vehicles Sold by Vehicle Type in {input_year}",
        labels={"Automobile_Sales": "Average automobile sales", "Vehicle_Type": "Vehicle type"},
    )

    yearly_ad_spend = yearly_data.groupby("Vehicle_Type", as_index=False)["Advertising_Expenditure"].sum()
    yearly_ad_spend["Vehicle_Type"] = pd.Categorical(yearly_ad_spend["Vehicle_Type"], VEHICLE_ORDER, ordered=True)
    yearly_ad_spend = yearly_ad_spend.sort_values("Vehicle_Type")
    chart4 = px.pie(
        yearly_ad_spend,
        values="Advertising_Expenditure",
        names="Vehicle_Type",
        title=f"Total Advertising Expenditure by Vehicle Type in {input_year}",
    )
    return [chart1, chart2, chart3, chart4]


def _chart_row(first, second):
    return html.Div(
        [
            dcc.Graph(figure=first, style={"flex": "1", "minWidth": "0"}),
            dcc.Graph(figure=second, style={"flex": "1", "minWidth": "0"}),
        ],
        className="chart-row",
        style={"display": "flex", "gap": "12px", "width": "100%"},
    )


def render_report(selected_statistics, input_year=None):
    """Return two rows of two graphs for the selected report."""
    if selected_statistics == REPORT_RECESSION:
        figures = make_recession_figures()
    elif selected_statistics == REPORT_YEARLY and input_year not in (None, "Select-year"):
        figures = make_yearly_figures(input_year)
        if not figures:
            return html.Div(f"No data is available for {input_year}.")
    else:
        return html.Div("Choose a report type; choose a year for yearly statistics.")
    return [_chart_row(figures[0], figures[1]), _chart_row(figures[2], figures[3])]


@app.callback(
    Output(component_id="select-year", component_property="disabled"),
    Input(component_id="dropdown-statistics", component_property="value"),
)
def _update_year_dropdown(selected_statistics):
    return update_input_container(selected_statistics)


@app.callback(
    Output(component_id="output-container", component_property="children"),
    [
        Input(component_id="dropdown-statistics", component_property="value"),
        Input(component_id="select-year", component_property="value"),
    ],
)
def update_output_container(selected_statistics, input_year):
    return render_report(selected_statistics, input_year)


if __name__ == "__main__":
    app.run(debug=False)
