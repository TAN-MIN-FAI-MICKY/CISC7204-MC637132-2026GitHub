# Module 05 Final Automobile Project — Automobile Sales

This folder contains the completed Part 1 notebook and Part 2 Dash dashboard, with the course data and requested report images. The notebook maps to R-01–R-11, the dashboard to R-12–R-17, the report PNGs to R-18, and the portable run package to R-19.

## Files

- `CISC7204 Assgn02 Module 05 Final Lab01 Visualizations with Matplotlib, Seaborn and Folium.ipynb` — completed notebook for tasks 1.1–1.9 plus optional Folium task 1.10. All code cells have saved outputs.
- `Dash_automobile.py` — interactive Dash application for yearly and recession reports.
- `automobile-sales.csv` and `us-states.json` — course data needed by the notebook, app and Folium choropleth.
- `AutomobileSalesRecessionChoropleth.html` — standalone Folium map. Its data and boundaries are embedded; the OpenStreetMap tile layer loads from the internet when viewed.
- `RecessionReportgraphs.png` and `YearlyReportgraphs.png` — the two required four-chart report images. The yearly screenshot uses 2008.
- `Lab01_Plots/` — PNG copies of the Matplotlib and Seaborn task outputs.
- `render_dash_screenshots.py` — script to regenerate the two Dash report images.
- `requirements.txt` — Python dependencies.

## Run the dashboard

From this folder in PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python Dash_automobile.py
```

Open `http://127.0.0.1:8050` in a browser. Choose a report type; the year menu is enabled only for yearly statistics.

To regenerate the report images, run `python render_dash_screenshots.py`. Kaleido requires a local Chrome or Chromium installation for PNG rendering.

## Run the notebook

Open the `.ipynb` file in Jupyter or VS Code with this folder as the working directory. The bundled CSV and GeoJSON are used before the notebook falls back to the course URLs.

## Data range

The dashboard year menu follows the linked data and skeleton example: 1980–2023. The Moodle page also contains an older 1980–2013 note; the supplied skeleton uses 1980–2023 and the data includes all years through 2023.

## Validation

The notebook ran all 20 code cells with no errors. The Dash layout and callback routes returned HTTP 200; both report callbacks returned four charts in two rows, and the year selector enabled/disabled correctly.
