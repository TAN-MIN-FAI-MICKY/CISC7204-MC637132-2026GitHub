"""Module 04 Lab 03 practice: callback bar chart by destination and airline."""

from pathlib import Path
import os

import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, html


DATA_PATH = Path(__file__).with_name("airline_data.csv")
DATA_URL = (
    "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/"
    "IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv"
)
TITLE = "Total number of flights to the destination state split by reporting airline"


def load_data(path: Path = DATA_PATH) -> pd.DataFrame:
    return pd.read_csv(
        path if path.exists() else DATA_URL,
        encoding="ISO-8859-1",
        dtype={"Div1Airport": str, "Div1TailNum": str, "Div2Airport": str, "Div2TailNum": str},
    )


def destination_airline_totals(data: pd.DataFrame, year: int) -> pd.DataFrame:
    selected = data.loc[data["Year"].eq(int(year))]
    return (
        selected.groupby(["DestState", "Reporting_Airline"], as_index=False)["Flights"]
        .sum()
    )


def create_bar_figure(data: pd.DataFrame, year: int):
    bar_data = destination_airline_totals(data, year)
    fig = px.bar(
        bar_data,
        x="DestState",
        y="Flights",
        color="Reporting_Airline",
        barmode="group",
        title=TITLE,
    )
    fig.update_layout(xaxis_title="DestState", yaxis_title="Flights")
    return fig


def create_app(data: pd.DataFrame | None = None) -> Dash:
    data = load_data() if data is None else data
    app = Dash(__name__)
    app.layout = html.Div(
        children=[
            html.H1(TITLE, style={"textAlign": "center", "color": "#503D36", "fontSize": 40}),
            html.Div(
                [
                    "Input Year: ",
                    dcc.Input(
                        id="input-year",
                        value=2010,
                        type="number",
                        style={"height": "50px", "fontSize": 35},
                    ),
                ],
                style={"fontSize": 40},
            ),
            html.Br(),
            dcc.Graph(id="bar-plot"),
        ]
    )

    @app.callback(Output("bar-plot", "figure"), Input("input-year", "value"))
    def update_bar_plot(entered_year):
        return create_bar_figure(data, int(entered_year or 2010))

    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "8050")), debug=False)
