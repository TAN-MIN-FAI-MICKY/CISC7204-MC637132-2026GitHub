"""Module 04 Lab 03: Year input and callback for monthly arrival delays."""

from pathlib import Path
import os

import pandas as pd
import plotly.graph_objects as go
from dash import Dash, Input, Output, dcc, html


DATA_PATH = Path(__file__).with_name("airline_data.csv")
DATA_URL = (
    "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/"
    "IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv"
)


def load_data(path: Path = DATA_PATH) -> pd.DataFrame:
    return pd.read_csv(
        path if path.exists() else DATA_URL,
        encoding="ISO-8859-1",
        dtype={"Div1Airport": str, "Div1TailNum": str, "Div2Airport": str, "Div2TailNum": str},
    )


def monthly_arrival_delay(data: pd.DataFrame, year: int) -> pd.DataFrame:
    selected = data.loc[data["Year"].eq(int(year))]
    return selected.groupby("Month", as_index=False)["ArrDelay"].mean()


def create_delay_figure(data: pd.DataFrame, year: int):
    line_data = monthly_arrival_delay(data, year)
    fig = go.Figure(
        data=go.Scatter(
            x=line_data["Month"],
            y=line_data["ArrDelay"],
            mode="lines",
            line={"color": "green"},
        )
    )
    fig.update_layout(
        title="Month vs Average Flight Delay Time",
        xaxis_title="Month",
        yaxis_title="ArrDelay",
    )
    return fig


def create_app(data: pd.DataFrame | None = None) -> Dash:
    data = load_data() if data is None else data
    app = Dash(__name__)
    app.layout = html.Div(
        children=[
            html.H1(
                "Airline Performance Dashboard",
                style={"textAlign": "center", "color": "#503D36", "fontSize": 40},
            ),
            html.Div(
                [
                    "Input Year: ",
                    dcc.Input(
                        id="input-year",
                        value=2010,
                        type="number",
                        style={"height": "50px", "fontSize": 35},
                    ),
                ],
                style={"fontSize": 40},
            ),
            html.Br(),
            dcc.Graph(id="line-plot"),
        ]
    )

    @app.callback(Output("line-plot", "figure"), Input("input-year", "value"))
    def update_line_plot(entered_year):
        return create_delay_figure(data, int(entered_year or 2010))

    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "8050")), debug=False)
