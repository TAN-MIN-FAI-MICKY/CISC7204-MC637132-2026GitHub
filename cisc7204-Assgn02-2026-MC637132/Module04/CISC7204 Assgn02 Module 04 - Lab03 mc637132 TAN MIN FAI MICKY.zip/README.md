# Module 04 Lab03 — Dash Interactivity

## Files
- `dash_interactivity.py` — year input and callback for monthly average arrival delay.
- `dash_interactivity_barplot.py` — year input and callback for destination-state flights split by reporting airline.
- `airline_data.csv` — dataset used by both apps.
- `requirements.txt` — Python package dependencies.

## Run
Create and activate a Python virtual environment, install `requirements.txt`, then run either app from this directory:

```powershell
python dash_interactivity.py
```

or

```powershell
python dash_interactivity_barplot.py
```

Only run one app at a time because both use the default local port. Open the URL printed in the terminal.
