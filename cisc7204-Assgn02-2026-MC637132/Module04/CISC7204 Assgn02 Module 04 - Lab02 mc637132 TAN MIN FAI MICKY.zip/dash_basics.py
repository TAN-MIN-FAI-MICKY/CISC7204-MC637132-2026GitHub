"""Module 04 Lab 02: Dash basics with HTML and core components."""

from pathlib import Path
import os

import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html


DATA_PATH = Path(__file__).with_name("airline_data.csv")
DATA_URL = (
    "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/"
    "IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv"
)


def load_data(path: Path = DATA_PATH) -> pd.DataFrame:
    """Load the airline dataset bundled beside this script."""
    return pd.read_csv(
        path if path.exists() else DATA_URL,
        encoding="ISO-8859-1",
        dtype={"Div1Airport": str, "Div1TailNum": str, "Div2Airport": str, "Div2TailNum": str},
    )


def create_pie_figure(data: pd.DataFrame):
    """Show the share of flights in each 250-mile distance group."""
    return px.pie(
        data,
        values="Flights",
        names="DistanceGroup",
        title="Distance group proportion by flights",
    )


def create_app(data: pd.DataFrame | None = None) -> Dash:
    data = load_data() if data is None else data
    app = Dash(__name__)
    app.layout = html.Div(
        children=[
            html.H1(
                "Airline On-time Performance Dashboard",
                style={"textAlign": "center", "color": "#503D36", "fontSize": 50},
            ),
            html.P(
                "Proportion of distance group (250 mile distance interval group) by flights.",
                style={"textAlign": "center", "color": "#F57241"},
            ),
            dcc.Graph(id="distance-group-pie", figure=create_pie_figure(data)),
        ]
    )
    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "8050")), debug=False)
