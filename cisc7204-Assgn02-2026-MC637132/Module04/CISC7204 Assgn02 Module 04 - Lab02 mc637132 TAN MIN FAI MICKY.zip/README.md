# Module 04 Lab02 — Dash Basics

## Files
- `dash_basics.py` — Dash app with a distance-group pie chart.
- `airline_data.csv` — dataset used by the app.
- `requirements.txt` — Python package dependencies.

## Run
Create and activate a Python virtual environment, install `requirements.txt`, then run:

```powershell
python dash_basics.py
```

Open the local URL printed in the terminal. The dashboard title reflects the Lab02 practice task.
