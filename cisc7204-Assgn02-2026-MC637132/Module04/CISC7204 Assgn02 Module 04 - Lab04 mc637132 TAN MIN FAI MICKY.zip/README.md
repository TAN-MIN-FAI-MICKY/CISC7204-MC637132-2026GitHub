# Module 04 Lab04 — Flight Delay Statistics Dashboard

## Files
- `flight_details.py` — final Dash app with five callback-driven delay charts. The Lab04 practice task asks to rename the script to this filename.
- `airline_data.csv` — dataset used by the app.
- `requirements.txt` — Python package dependencies.

## Run
Create and activate a Python virtual environment, install `requirements.txt`, then run:

```powershell
python flight_details.py
```

Open the local URL printed in the terminal.
