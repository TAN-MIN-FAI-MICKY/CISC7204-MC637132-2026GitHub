"""Module 04 Lab 04: Flight Delay Time Statistics Dash dashboard."""

from pathlib import Path
import os

import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, html


DATA_PATH = Path(__file__).with_name("airline_data.csv")
DATA_URL = (
    "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/"
    "IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv"
)
DELAY_COLUMNS = [
    ("CarrierDelay", "Average carrier delay time (minutes) by airline"),
    ("WeatherDelay", "Average weather delay time (minutes) by airline"),
    ("NASDelay", "Average NAS delay time (minutes) by airline"),
    ("SecurityDelay", "Average security delay time (minutes) by airline"),
    ("LateAircraftDelay", "Average late aircraft delay time (minutes) by airline"),
]


def load_data(path: Path = DATA_PATH) -> pd.DataFrame:
    return pd.read_csv(
        path if path.exists() else DATA_URL,
        encoding="ISO-8859-1",
        dtype={"Div1Airport": str, "Div1TailNum": str, "Div2Airport": str, "Div2TailNum": str},
    )


def compute_info(data: pd.DataFrame, year: int) -> list[pd.DataFrame]:
    selected = data.loc[data["Year"].eq(int(year))]
    return [
        selected.groupby(["Month", "Reporting_Airline"], as_index=False)[column].mean()
        for column, _ in DELAY_COLUMNS
    ]


def create_delay_figures(data: pd.DataFrame, year: int):
    monthly_data = compute_info(data, year)
    figures = []
    for (column, title), frame in zip(DELAY_COLUMNS, monthly_data):
        fig = px.line(
            frame,
            x="Month",
            y=column,
            color="Reporting_Airline",
            title=title,
        )
        fig.update_layout(xaxis_title="Month", yaxis_title="Average delay (minutes)")
        figures.append(fig)
    return figures


def create_app(data: pd.DataFrame | None = None) -> Dash:
    data = load_data() if data is None else data
    app = Dash(__name__)
    app.layout = html.Div(
        children=[
            html.H1(
                "Flight Details Statistics Dashboard",
                style={"textAlign": "center", "color": "#503D36", "fontSize": 35},
            ),
            html.Div(
                [
                    "Input Year: ",
                    dcc.Input(
                        id="input-year",
                        value=2010,
                        type="number",
                        style={"height": "35px", "fontSize": 30},
                    ),
                ],
                style={"fontSize": 30},
            ),
            html.Br(),
            html.Br(),
            html.Div(
                [dcc.Graph(id="carrier-plot"), dcc.Graph(id="weather-plot")],
                style={"display": "flex"},
            ),
            html.Div(
                [dcc.Graph(id="nas-plot"), dcc.Graph(id="security-plot")],
                style={"display": "flex"},
            ),
            html.Div(dcc.Graph(id="late-plot"), style={"width": "65%"}),
        ]
    )

    @app.callback(
        [
            Output("carrier-plot", "figure"),
            Output("weather-plot", "figure"),
            Output("nas-plot", "figure"),
            Output("security-plot", "figure"),
            Output("late-plot", "figure"),
        ],
        Input("input-year", "value"),
    )
    def update_delay_charts(entered_year):
        return create_delay_figures(data, int(entered_year or 2010))

    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "8050")), debug=False)
